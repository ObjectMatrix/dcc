@echo off
REM ============================================================
REM  DCC Python Class - One-Click Setup for Windows
REM  What this does:
REM    1. Checks if Python 3 is installed (installs it if not)
REM    2. Creates a folder called "dcc" in your user folder
REM    3. Creates a private Python environment (venv) inside it
REM    4. Installs JupyterLab + class libraries (requests, folium)
REM    5. Starts JupyterLab in your browser
REM  Safe to run again anytime - it skips steps already done.
REM ============================================================

setlocal EnableDelayedExpansion
title DCC Python Setup

set "DCC_DIR=%USERPROFILE%\dcc"
set "VENV_DIR=%DCC_DIR%\venv"
set "PYEXE="

echo.
echo  ==========================================
echo   DCC Python Class Setup
echo  ==========================================
echo.

REM ---------- STEP 1: Find Python ----------
echo [1/5] Looking for Python 3...

REM Try the official "py" launcher first (most reliable on Windows)
py -3 -c "print('ok')" >nul 2>&1
if not errorlevel 1 (
    for /f "delims=" %%i in ('py -3 -c "import sys; print(sys.executable)"') do set "PYEXE=%%i"
    goto :python_found
)

REM Try "python" on PATH (but reject the Microsoft Store fake stub)
python -c "print('ok')" >nul 2>&1
if not errorlevel 1 (
    for /f "delims=" %%i in ('python -c "import sys; print(sys.executable)"') do set "PYEXE=%%i"
    goto :python_found
)

REM Try the default per-user install locations
for %%V in (313 312 311 310) do (
    if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
        goto :python_found
    )
)

REM ---------- Python not found: install it ----------
echo       Python not found. Installing Python 3.12 (this takes a few minutes)...
echo.

REM Try winget first (built into Windows 10/11)
winget --version >nul 2>&1
if not errorlevel 1 (
    echo       Installing via winget...
    winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
) else (
    echo       Downloading the official installer from python.org...
    curl -L -o "%TEMP%\dcc-python-installer.exe" https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe
    if errorlevel 1 (
        echo.
        echo  ERROR: Could not download Python. Check your internet connection
        echo  or install Python manually from https://www.python.org/downloads/
        pause
        exit /b 1
    )
    echo       Running the installer quietly...
    start /wait "" "%TEMP%\dcc-python-installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0
)

REM Find Python again after installing (PATH in this window is stale,
REM so we look in the standard install folder directly)
for %%V in (313 312 311 310) do (
    if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
        goto :python_found
    )
)

py -3 -c "print('ok')" >nul 2>&1
if not errorlevel 1 (
    for /f "delims=" %%i in ('py -3 -c "import sys; print(sys.executable)"') do set "PYEXE=%%i"
    goto :python_found
)

echo.
echo  ERROR: Python was installed but could not be found automatically.
echo  Please close this window, then double-click this script once more.
pause
exit /b 1

:python_found
echo       Found Python: !PYEXE!
echo.

REM ---------- STEP 2: Create the dcc working folder ----------
echo [2/5] Creating your class folder: %DCC_DIR%
if not exist "%DCC_DIR%" mkdir "%DCC_DIR%"
echo.

REM ---------- STEP 3: Create the venv (skip if it exists) ----------
echo [3/5] Setting up the Python environment (venv)...
if exist "%VENV_DIR%\Scripts\python.exe" (
    echo       venv already exists - skipping.
) else (
    "!PYEXE!" -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo.
        echo  ERROR: Could not create the venv.
        pause
        exit /b 1
    )
)
set "VPY=%VENV_DIR%\Scripts\python.exe"
echo.

REM ---------- STEP 4: Install JupyterLab + class libraries ----------
echo [4/5] Installing JupyterLab, requests, and folium...
echo       (first time takes a few minutes - grab a snack)
"%VPY%" -m pip install --upgrade pip --quiet
"%VPY%" -m pip install jupyterlab requests folium --quiet
if errorlevel 1 (
    echo.
    echo  ERROR: Package install failed. Check your internet connection
    echo  and run this script again.
    pause
    exit /b 1
)
echo.

REM ---------- STEP 5: Launch JupyterLab ----------
echo [5/5] Starting JupyterLab... your browser will open shortly.
echo.
echo  ==========================================
echo   Setup complete! Leave this window OPEN
echo   while you work. Close it to stop Jupyter.
echo  ==========================================
echo.
cd /d "%DCC_DIR%"
"%VPY%" -m jupyter lab

pause
