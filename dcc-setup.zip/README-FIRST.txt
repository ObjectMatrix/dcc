==========================================================
 DCC PYTHON CLASS - COMPUTER SETUP INSTRUCTIONS
==========================================================

Please do this BEFORE the first class. It takes about
10 minutes and needs an internet connection.

WHAT YOU NEED
  - A Windows 10 or Windows 11 laptop
  - Internet connection
  - No admin password needed (installs for your user only)

STEP-BY-STEP
  1. This zip file contains a file called: dcc-setup.bat
     Right-click the zip and choose "Extract All...", then
     open the extracted folder.
     (Do NOT double-click the file while it is still
     inside the zip - extract it first.)

  2. Double-click  dcc-setup.bat

  3. If Windows shows a blue box saying
     "Windows protected your PC":
        click  "More info"  then  "Run anyway"
     This appears because the file is not from a big
     software company. It is safe - you can open it in
     Notepad and read every line.

  4. A black window opens and shows 5 steps:
        [1/5] Looking for Python
        [2/5] Creating your class folder
        [3/5] Setting up the environment
        [4/5] Installing JupyterLab
        [5/5] Starting JupyterLab
     The FIRST run takes 5-10 minutes. Be patient!

  5. When it finishes, your web browser opens with
     "JupyterLab" - that is where we will write Python.

  6. IMPORTANT: keep the black window open while using
     JupyterLab. Closing it stops everything (that is
     also how you quit when you are done).

EVERY CLASS AFTER THE FIRST
  Just double-click dcc-setup.bat again. It skips the
  installing and jumps straight to JupyterLab in about
  10 seconds.

WHERE YOUR WORK IS SAVED
  All notebooks are saved in a folder called "dcc"
  inside your user folder:  C:\Users\<your name>\dcc

IF SOMETHING GOES WRONG
  - Close the black window and double-click the file
    once more. It is safe to run again.
  - Still stuck? Bring the laptop to class 15 minutes
    early and we will fix it together.

See you in class!
  - DCC (Delta Community Center)
==========================================================
